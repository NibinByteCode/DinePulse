import React from 'react'

export const DashboardSettings = () => {
  return (
    <main className='main-container'>
        <div className='main-title'>
            <h3>SETTINGS</h3>
        </div>
        <br/><br/>

        <div className="section_settings">
            <div className="formbox settings">
                <form action="">
                    <h1>Login here...</h1>
                    <br/>
                    <div className="inputbox">
                        <label>aaaaa : </label>
                        <label>aaaaaaaaaaaaaa</label>
                    </div>
                    <div className="inputbox"> 
                        <label>bbbbb : </label>
                        <label>bbbbbbbbbbbbb</label>   
                    </div>
                    <div className="inputbox"> 
                        <label>ccccc : </label>
                        <label>cccccccccccc</label>   
                    </div>
                    <div className="inputbox"> 
                        <label>ddddd : </label>
                        <label>ddddddddddd</label>   
                    </div>
                </form>
            </div>
        </div>
    </main>
  )
}
